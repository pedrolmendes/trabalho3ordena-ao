#include <stdio.h>

// Fun��o para exibir o array
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Bubble Sort: Ordena��o por troca
void bubbleSort(int arr[], int n) {
    // Percorre o array v�rias vezes
    for (int i = 0; i < n - 1; i++) {
        // �ltimos elementos j� estar�o ordenados, ent�o a cada itera��o reduzimos o alcance
        for (int j = 0; j < n - i - 1; j++) {
            // Verifica se os elementos adjacentes est�o fora de ordem
            if (arr[j] > arr[j + 1]) {
                // Troca os elementos
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// Insertion Sort: Ordena��o por inser��o
void insertionSort(int arr[], int n) {
    // Inicia a partir do segundo elemento, considerando o primeiro j� ordenado
    for (int i = 1; i < n; i++) {
        int key = arr[i]; // Elemento a ser inserido na sublista ordenada
        int j = i - 1;
        // Move os elementos maiores para a frente
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        // Insere o elemento na posi��o correta
        arr[j + 1] = key;
    }
}

// Selection Sort: Ordena��o por sele��o
void selectionSort(int arr[], int n) {
    // Percorre o array
    for (int i = 0; i < n - 1; i++) {
        // Assume que o menor elemento est� na posi��o atual
        int min_idx = i;
        // Procura o menor elemento no restante do array
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j; // Atualiza o �ndice do menor elemento
            }
        }
        // Troca o menor elemento encontrado com o elemento atual
        int temp = arr[min_idx];
        arr[min_idx] = arr[i];
        arr[i] = temp;
    }
}

// Fun��o principal para testar os m�todos
int main() {
    int arr[] = {64, 34, 25, 12, 22, 11, 90}; // Array de exemplo
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Array original:\n");
    printArray(arr, n);

    // Testando o Bubble Sort
    bubbleSort(arr, n);
    printf("\nArray ordenado com Bubble Sort:\n");
    printArray(arr, n);

    // Restaurando o array original
    int arr2[] = {64, 34, 25, 12, 22, 11, 90};
    insertionSort(arr2, n);
    printf("\nArray ordenado com Insertion Sort:\n");
    printArray(arr2, n);

    // Restaurando o array original
    int arr3[] = {64, 34, 25, 12, 22, 11, 90};
    selectionSort(arr3, n);
    printf("\nArray ordenado com Selection Sort:\n");
    printArray(arr3, n);

    return 0;
}

